#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

class DadosBancarios():
  def __init__(self,cartao,cv):
    self.cartao = cartao
    self.cv = cv

  def setSenha(self,senha):
    self.senha = senha

  def realizarPagamento(self,cartao,cv,senha):
    if cartao == self.cartao and cv == self.cv and senha == self.senha:
      return True 
    else:
      return False


