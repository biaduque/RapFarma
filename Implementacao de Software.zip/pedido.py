#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

class Pedido():
  def __init__(self,produtos,endereco,num,cep,estado):
    self.produtos = produtos
    self.pedido_ID = 0
    self.endereco = endereco
    self.num = num
    self.cep = cep
    self.estado = estado

class Produto():
  def __init__(self,preco,categoria,quantidade,nome,foto):
    self.preco = preco
    self.categoria = categoria
    self.quantidade = quantidade
    self.nome = nome 
    self.foto = foto

  def setDescricao(self):
    self.descricao = input("Digite a descricao do seu produto aqui: ")
    
