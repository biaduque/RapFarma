#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

from pedido import Produto
from dadosBancarios import DadosBancarios

class Farmacia():
  def __init__(self, nome, endereco, num, cep, cnpj, email, senha, telefone, dados_bancarios):
    self.nome = nome
    self.endereco = endereco
    self.num = num
    self.cep = cep
    self.cnpj = cnpj
    self.email = email
    self.senha = senha
    self.dados_bancarios = dados_bancarios
    self.catalogo = []
    self.pedidos = []

  def addCatalogo(self,produto):
    self.catalo.append(produto)

  def consultarCatalogo(self):
    for i in range (0,len(self.catalogo),1):
      print(self.catalogo[i])
  
  def confirmarPedido(self,pedido):
    self.pedidos.append(pedido)
  
  def visualizarPedidos(self): 
    for i in range (0,len(self.pedidos),1):
      print(self.pedidos[i])

  def setDadosBancarios(self,cartao,cv):
    self.cartao = cartao
    self.cv = cv
    self.dados_bancarios = DadosBancarios(cartao,cv)

