#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

from pedido import Pedido
from dadosBancarios import DadosBancarios

class Cliente():
  def __init__(self,CPF,nome,endereco,num,cep,telefone,data_nascimento,email,senha):
    self.CPF = CPF
    self.nome = nome
    self.endereco = endereco
    self.num = num
    self.cep = cep
    self.telefone = telefone
    self.data = data_nascimento
    self.email = email
    self.senha = senha
    self.carrinho = []
    self.pedidos = []

  def setDadosBancarios(self,cartao,cv):
    #seta os dados bancarios do cliente
    self.cartao = cartao
    self.cv = cv
    self.dados_bancarios = DadosBancarios(cartao,cv)
    senhaCartao = input("Digite sua senha: ")
    self.setSenha(senhaCartao)

  def consultarCatalogo(self,farmacia):
    #consulta o catalogo de uma determinada farmacia
    for i in range (0,len(farmacia.catalogo),1):
      print(farmacia.catalogo[i])

  def consultarPedidos(self):
    #consulta os pedidos que ja realizou
    for i in range (0,len(self.pedidos),1):
      print(self.pedidos[i])

  def realizarPedido(self):
    pagamento = False
    #cria um novo pedido
    pedido = Pedido(self.carrinho, self.endereco, self.num, self.cep)
    self.pedidos.append(pedido)
    senhaCartao = input("Digite sua senha: ")
    pagamento = self.dados_bancarios.realizarPagamento(self.cartao,self.cv,senhaCartao)
    if pagamento == True: 
      print("Pagamento efetuado!")
      pedido.estado = "Aguardando retirada"
    else: 
      print("Pagamento não efetuado com sucesso")

  def addCarrinho(self,produto):
    #adiciona um produto no carrinho do cliente 
    self.carrinho.append(produto)

  def removeCarrinho(self,i):
    #remove um produto nmove um pro carrinho do cliente
    del(self.carrinho[i])

  def consultarCarrinho(self): 
    #consulta o carrinho do cliente
    for i in range (0,len(self.carrinho),1):
      print(self.carrinho[i])

  def editarDados(self,telefone,email,senha,endereco,num,cep): 
    self.telefone = telefone
    self.email = email 
    self.cep = cep
    self.num = num
    self.endereco = endereco 

    if senha == self.senha:
      novaSenha = input("Digite a nova senha:")
      self.senha = novaSenha

      
    
