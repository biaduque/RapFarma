#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

class DadosBancarios():
  def __init__(self,cartao,cv):
    self.cartao = cartao
    self.cv = cv
    self.forma = 0

  def getFormaPagamento(self,forma):
    print("1.Crédito")
    print("2.Débito")
    self.forma = forma

  def setSenha(self,senha):
    self.senha = senha

  def getCartao(self):
    return self.cartao

  def getCV(self):
    return self.cv

  def realizarPagamento(self,senha):
    if senha == self.senha:
      return True 
    else:
      return False