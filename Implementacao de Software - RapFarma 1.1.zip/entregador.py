#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

from dadosBancarios import DadosBancarios

class Entregador:
  def __init__(self,nome,CPF,numeroEnd,endereco,complemento,cep,telefone,nascimento,cartao,conta,banco):
    self.nome=nome
    self.CPF=CPF
    self.numeroEnd=numeroEnd
    self.complemento=complemento
    self.cep=cep
    self.telefone=telefone
    self.nascimento=nascimento
    self.cartao=cartao
    self.conta=conta
    self.banco=banco
    self.pedidos = []

  def escolherPedido(self, pedido):
    self.pedido = pedido

  def setDadosBancarios(self,cartao,cv):
    self.cartao = cartao
    self.cv = cv
    self.dados_bancarios = DadosBancarios(cartao,cv)
