#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

############################## Main para testes ##############################
from cliente import Cliente
from pedido import Produto
precos = [20.0,10.0,30.0,49.0]
categorias = ["geriatria","cuidados","remedio","beleza"]
qtd = [1,2,3,4,5]
nome = ["fralda","escova de dente","rivotril","esmalte"]

c = Cliente(502,"Jao","Rua",555,4329,368,"15/11","pinho@foda","coxinha123")
for x in range(4):
  prod = Produto(precos[x],categorias[x],qtd[x],nome[x],"foto.png")
  c.addCarrinho(prod)
c.consultarCarrinho()
#c.removeCarrinho(2)
#c.setDadosBancarios(1111,222)
#c.realizarPedido()