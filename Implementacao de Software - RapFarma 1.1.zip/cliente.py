#Beatriz Duque - 31906621
#João Pedro Leite Belforti - 31954162
#Felipe Pereira Pinho - 31958982
#Marcos Paulo Hideki Onishi - 31927416

from pedido import Pedido
from dadosBancarios import DadosBancarios

class Cliente():
  def __init__(self,CPF,nome,endereco,num,cep,telefone,data_nascimento,email,senha):
    self.CPF = CPF
    self.nome = nome
    self.endereco = endereco
    self.num = num
    self.cep = cep
    self.telefone = telefone
    self.data = data_nascimento
    self.email = email
    self.senha = senha
    self.carrinho = []
    self.pedidos = []
    self.dados_bancarios = None

  def setDadosBancarios(self,cartao,cv):
    #seta os dados bancarios do cliente
    self.dados_bancarios = DadosBancarios(cartao,cv)
    senhaCartao = input("Digite sua senha: ")
    self.dados_bancarios.setSenha(senhaCartao)

  def consultarCatalogo(self,farmacia):
    #consulta o catalogo de uma determinada farmacia
    for i in range (0,len(farmacia.catalogo),1):
      print(farmacia.catalogo[i])

  def consultarPedidos(self):
    #consulta os pedidos que ja realizou
    for i in range (0,len(self.pedidos),1):
      print(self.pedidos[i])

  def realizarPedido(self):
    pagamento = False
    #cria um novo pedido
    if(len(self.carrinho)==0):
      print("0 Produtos presentes no carrinho.")
      return
    pedido = Pedido(self.carrinho, self.endereco, self.num, self.cep, "Aguardando Pagamento")
    self.pedidos.append(pedido)

    #Definindo a forma de pagamento
    forma = 0
    while forma!=1 or forma!=2: 
       forma = input("Escolha a forma de pagamento: 1.Crédito 2.Débito")

    #Setando a forma de pagamento na funcao   
    self.dados_bancarios.getFormaPagamento(forma)

    #Definindo dados bancários
    if(self.dados_bancarios == None):
      cartao=str(input("Digite o numero do cartao: "))
      cv=int(input("Digite o CV: "))
      self.setDadosBancarios(cartao,cv)
    senhaCartao = input("Digite sua senha: ")
    pagamento = self.dados_bancarios.realizarPagamento(senhaCartao)
    if pagamento == True:
      print("Pagamento efetuado com sucesso!")
      pedido.estado = "Aguardando retirada"
    else:
      print("Pagamento não efetuado!") 

  def addCarrinho(self,produto):
    #adiciona um produto no carrinho do cliente 
    self.carrinho.append(produto)

  def removeCarrinho(self,i):
    #remove um produto nmove um pro carrinho do cliente
    if(i >= 0 and i < len(self.carrinho)):
      del(self.carrinho[i])
      self.consultarCarrinho()
    else:
      print("Posicao invalida!")

  def consultarCarrinho(self): 
    total = 0 
    #consulta o carrinho do cliente
    for i in range (0,len(self.carrinho),1):
      self.carrinho[i].printProd()
      total += self.carrinho[i].preco
    print("TOTAL R$",total)

  def editarDados(self,telefone,email,senha,endereco,num,cep): 
    self.telefone = telefone
    self.email = email 
    self.cep = cep
    self.num = num
    self.endereco = endereco 

    if senha == self.senha:
      novaSenha = input("Digite a nova senha:")
      self.senha = novaSenha

      
    
